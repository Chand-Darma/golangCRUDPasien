# go-crud

Source code tutorial membuat sistem CRUD dengan Golang dan database MySQL

Youtube Tutorial: [Golang CRUD MySQL dan Form Validation](https://youtu.be/gHtRBGqXYlA)
